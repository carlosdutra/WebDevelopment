﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WilcoxCollege.Models
{
    public static class Repository
    {
        private static List<Course> courses = new List<Course>();

        public static IEnumerable<Course> Courses
        {
            get
            {
                return courses;
            }
        }

        public static void AddCourse(Course course)
        {
            courses.Add(course);
        }
    }
}
