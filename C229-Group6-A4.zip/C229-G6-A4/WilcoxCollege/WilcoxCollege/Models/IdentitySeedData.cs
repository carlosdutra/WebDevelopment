﻿using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WilcoxCollege.Models
{
    public class IdentitySeedData
    {
        //Admin user
        private const string UserAdmin = "Admin";
        private const string adminPassword = "Secret123$";

        //General user
        private const string generalUser = "General";
        private const string generalPassword = "Secret123$";

        public static async void EnsurePopulated(IApplicationBuilder app)
        {
            UserManager<IdentityUser> userManager = app.ApplicationServices
            .GetRequiredService<UserManager<IdentityUser>>();

            IdentityUser admin = await userManager.FindByIdAsync(UserAdmin);
            if (admin == null)
            {
                admin = new IdentityUser("Admin");
                await userManager.CreateAsync(admin, adminPassword);
            }

            IdentityUser general = await userManager.FindByIdAsync(generalUser);
            if (general == null)
            {
                general = new IdentityUser("General");
                await userManager.CreateAsync(general, generalPassword);
            }
        }
    }
}
