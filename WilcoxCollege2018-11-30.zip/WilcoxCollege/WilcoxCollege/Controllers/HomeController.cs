﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using WilcoxCollege.Models;
using WilcoxCollege.Models.ViewModels;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace WilcoxCollege.Controllers
{
    public class HomeController : Controller
    {
        // GET: /<controller>/
        public ViewResult Index()
        {
            ViewBag.Title = "Wilcox College - Home";
            ViewBag.Message = "Wilcox College";
            return View();
        }

        private ICourseRepository courseRepository;
        //private IStudentRepository studentRepository;
        
        public HomeController(ICourseRepository course)
        {
            courseRepository = course;
        }

        //Model for all courses to list on DisplayPage
        public ViewResult DisplayPage()
        {
            ViewBag.Title = "Display Page";
            return View(courseRepository.Courses.Where(r => r.CourseName != null));
        }

        //Open course based on Id on DataPage
        public ViewResult DataPage(int courseId)
        {
            ViewBag.Title = "Data Page";
            return View(courseRepository.Courses.FirstOrDefault(c => c.CourseID == courseId));
        }
                
        public ViewResult InsertPage()
        {
            ViewBag.Title = "Insert Page";
            return View();
        }

        //Insert Course into Db
        [HttpPost]
        public ViewResult InsertPage(Course course)
        {
            if (ModelState.IsValid)
            {
                courseRepository.SaveCourse(course);
                return View("DisplayPage", courseRepository.Courses);
            }
            else
            {
                // there is a validation error
                return View();
            }
        }
        
        //Edit Course on DataPage
        [HttpPost]
        public IActionResult Update(Course course)
        {
            if (ModelState.IsValid)
            {
                courseRepository.SaveCourse(course);
                return RedirectToAction("DisplayPage");
            }
            else
            {
                // there is something wrong with the data values
                return View(course);
            }
        }

        //DeleteCourse
        [HttpPost]
        public IActionResult Delete(int courseId)
        {
            Course deletedCourse = courseRepository.DeleteCourse(courseId);
            if (deletedCourse != null)
            {
                TempData["message"] = $"{deletedCourse.CourseName} was deleted";
            }
            return RedirectToAction("DisplayPage");
        }
    }
}
