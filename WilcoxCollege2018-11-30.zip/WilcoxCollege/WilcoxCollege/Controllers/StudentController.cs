﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using WilcoxCollege.Models;
using WilcoxCollege.Models.ViewModels;

namespace WilcoxCollege.Controllers
{
    public class StudentController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        private IStudentRepository studentRepository;
        private ICourseRepository courseRepository;

        public StudentController(ICourseRepository course, IStudentRepository student)
        {
            courseRepository = course;
            studentRepository = student;
        }
        
        //List of Students
        public ViewResult ListOfStudents(int courseId)
        {
            return View(studentRepository.Students.Where(s => s.Course.CourseID == courseId));
        }        

        //Model for all courses to list on UserPage
        public ViewResult UserPage()
        {
            ViewBag.Title = "User Page";
            return View(courseRepository.Courses.Where(r => r.CourseName != null));
        }

        [HttpGet]
        public ViewResult NewStudentPage(int courseId)
        {
            CourseStudentViewModel interaction = new CourseStudentViewModel();

            interaction.CourseID = courseId;

            return View("NewStudentPage", interaction);
        }

        [HttpPost]
        public IActionResult NewStudentPage(int courseId, Student student)
        {
            Course course = courseRepository.Courses.FirstOrDefault(c => c.CourseID == courseId);

            course.AddStudent(student);
            studentRepository.SaveStudent(student);

            return RedirectToAction("RedirectToUser");
        }
        public IActionResult RedirectToUser()
        {
            return View("UserPage", courseRepository.Courses.Where(r => r.CourseName != null));
        }
    }
}