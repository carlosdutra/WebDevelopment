﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WilcoxCollege.Models
{
    public class EFStudentRepository : IStudentRepository
    {
        private ApplicationDbContext context;

        public EFStudentRepository(ApplicationDbContext ctx)
        {
            context = ctx;
        }

        public IQueryable<Student> Students => context.Students.Include(c => c.Course);

        public void SaveStudent(Student student)
        {
            context.Attach(student.Course);
            if (student.StudentID == 0)
            {
                context.Students.Add(student);
            }
            context.SaveChanges();
        }

    }
}
