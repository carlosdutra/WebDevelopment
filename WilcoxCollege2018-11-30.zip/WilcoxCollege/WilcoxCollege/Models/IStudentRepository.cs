﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WilcoxCollege.Models
{
    public interface IStudentRepository
    {
        IQueryable<Student> Students { get; }
        void SaveStudent(Student student);
    }
}
