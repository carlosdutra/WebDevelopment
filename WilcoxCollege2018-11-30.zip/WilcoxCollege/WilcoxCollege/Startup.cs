﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using WilcoxCollege.Models;

namespace WilcoxCollege
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        // For more information on how to configure your application, visit https://go.microsoft.com/fwlink/?LinkID=398940
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddDbContext<ApplicationDbContext>
                (options => options.UseSqlServer(
                    Configuration["Data:WilcoxCollegeData:ConnectionString"]));
            services.AddTransient<ICourseRepository, EFCourseRepository>();
            services.AddTransient<IStudentRepository, EFStudentRepository>();
            services.AddMvc();
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            app.UseDeveloperExceptionPage();
            app.UseStatusCodePages();
            app.UseStaticFiles();

            app.UseMvc(routes =>
            {
                routes.MapRoute(
                name: null,
                template: "",
                defaults: new { controller = "Home", action = "Index" }
                );

                routes.MapRoute(
                name: null,
                template: "Courses",
                defaults: new { controller = "Home", action = "DisplayPage" }
                );

                routes.MapRoute(
                name: null,
                template: "Courses/Edit/{courseId:int?}",
                defaults: new { controller = "Home", action = "DataPage" }
                );
                
                routes.MapRoute(
                name: null,
                template: "Courses/Register",
                defaults: new { controller = "Home", action = "InsertPage" }
                );

                routes.MapRoute(
                name: null,
                template: "Courses/NewStudent",
                defaults: new { controller = "Student", action = "UserPage" }
                );

                routes.MapRoute(
                name: null,
                template: "Courses/NewStudent/{courseId:int?}",
                defaults: new { controller = "Student", action = "NewStudentPage" }
                );

                routes.MapRoute(name: null, template: "{controller}/{action}/{id?}");

            });

            //app.UseMvcWithDefaultRoute();

            SeedData.EnsurePopulated(app);
        }
    }
}
