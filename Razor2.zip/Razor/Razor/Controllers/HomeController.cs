﻿using Microsoft.AspNetCore.Mvc;
using Razor.Models;

namespace Razor.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            ViewBag.StockLevel = 2;
            Product[] myProducts = {
                new Product { ProductID = 1, Name = "Kayak", Description = "A boat", Category = "Watersports", Price = 200M },
                new Product { ProductID = 2, Name = "Lifejacket", Description = "Life Jacket", Category = "Watersports", Price = 50M }              
            };
            return View(myProducts);
        }
    }
}