var provinces = ["Ontario", "British Columbia", "Sasktchewan", "Alberta", "Manitoba", "Prince Edward Island", "New Brunswick", 
                    "Nova Scotia", "Quebec"];

var text;

text = "<ul>";
for (i=0 ; i <= provinces.length ; i++)
{
        text+= "<li>" + provinces[i] + "</li>";
}
    
text+= "</ul>";
document.getElementById("provincesList").innerHTML = text;