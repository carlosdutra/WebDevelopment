function metric()
{
    document.getElementById("weight").placeholder= "kg";
    document.getElementById("age").placeholder= "years";
    
    document.getElementById("in").style.display = "none";
    document.getElementById("ft").style.display = "none";
    document.getElementById("height").style.display = "unset";    
}

function imperial()
{
    document.getElementById("weight").placeholder = "pounds";
    document.getElementById("age").placeholder = "years";
    
    document.getElementById("in").style.display = "unset";
    document.getElementById("ft").style.display = "unset";
    document.getElementById("height").style.display = "none";
}

function Calc()
{
    if (document.getElementById("metric").checked == true)
    {
        CalcMetric();
    }
    else if (document.getElementById("imperial").checked == true)
    {
        CalcImperial(); 
    }
}

function CalcAct(valueAc)
{
    var dailyActivities = document.getElementsByName("activities");
    var value_activities; //Flag
    
    value_activities = valueAc;

    for (i = 0; i < dailyActivities.length; i++)
    {
        if(dailyActivities[i].checked)
        {
            value_activities = dailyActivities[i].value;
        }
    }
    
    return value_activities;
}







function CalcMetric()
{           
    var dailyActivities = document.getElementsByName("activities");
    var value_activities; //Flag

    for (i = 0; i < dailyActivities.length; i++)
    {
        if(dailyActivities[i].checked)
        {
            value_activities = dailyActivities[i].value;
        }
    }
    
    //Get all values
    var gender = document.getElementById("gender").value;
    var weight = document.getElementById("weight").value;
    var height = document.getElementById("height").value;
    var age = document.getElementById("age").value;
    
    //Check gender
    if(gender == "male") 
    {
        var firstOp = 13.75 * weight;
        var secondOp = 5.003 * height;
        var thirdOp = 6.755 * age;

        var bmr = (66.5 + firstOp + secondOp) - thirdOp;
        var bmr2 = bmr * value_activities;
        
        document.getElementById("DisplayResult").innerHTML = "BMR: " + bmr2.toFixed(2) + " Calories/day";
    }
    
    else if(gender == "female")
    {
        var firstOp = 9.563 * weight;
        var secondOp = 1.850 * height;
        var thirdOp = 4.676 * age;

        var bmr = (655.1 + firstOp + secondOp) - thirdOp;                
        var bmr2 = bmr * value_activities;
        
        document.getElementById("DisplayResult").innerHTML = "BMR: " + bmr2.toFixed(2) + " Calories/day";
    } 
}

function CalcImperial()
{
    var dailyActivities = document.getElementsByName("activities"); //Get the value of input radios
    var value_activities;

    for (i = 0; i < dailyActivities.length; i++)
    {
        if(dailyActivities[i].checked)
        {
            value_activities = dailyActivities[i].value;
        }
    }
    
    //Get all values
    var gender = document.getElementById("gender").value;
    var weight = document.getElementById("weight").value;
    var height = (document.getElementById("ft").value * 12) + (document.getElementById("in").value * 1);
    var age = document.getElementById("age").value;
    
    //Check gender
    if(gender == "male") 
    {
        var firstOp = 6.2 * weight;
        var secondOp = 12.7 * height;
        var thirdOp = 6.76 * age;

        var bmr = (66 + firstOp + secondOp) - thirdOp;
        var bmr2 = bmr * value_activities;
        
        document.getElementById("DisplayResult").innerHTML = "BMR: " + bmr2.toFixed(2) + " Calories/day";
    }
    
    else if(gender == "female")
    {
        var firstOp = 4.35 * weight;
        var secondOp = 4.7 * height;
        var thirdOp = 4.7 * age;

        var bmr = (655.1 + firstOp + secondOp) - thirdOp;
        var bmr2 = bmr * value_activities;
        
        document.getElementById("DisplayResult").innerHTML = "BMR: " + bmr2.toFixed(2) + " Calories/day";
    }

}