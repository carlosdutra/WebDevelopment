function confirmPassword()
{
    var p1 = document.getElementById("password1").value;
    var p2 = document.getElementById("password2").value;
    
    if ( p1 != p2)
        {
            alert("Passwords are not the same!")
        }
}

//Set the input date to max of eighteen years in the past
function setMinimumDate()
{
    var Todaydate = new Date();
    var newDate = Todaydate.getFullYear() - 18;
    
    document.getElementById("dob").setAttribute("max", newDate + "-12-31");
}

//Set the input date to max of eighteen years in the past
var body = document.getElementsByTagName("body")[0];
body.addEventListener("load", setMinimumDate(), false);

