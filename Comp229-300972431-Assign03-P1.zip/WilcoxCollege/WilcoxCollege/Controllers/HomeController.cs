﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using WilcoxCollege.Models;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace WilcoxCollege.Controllers
{
    public class HomeController : Controller
    {
        // GET: /<controller>/
        public ViewResult Index()
        {
            ViewBag.Title = "Wilcox College - Home";
            ViewBag.Message = "Wilcox College";
            return View();
        }

        private ICourseRepository courseRepository;
        public HomeController(ICourseRepository course)
        {
            courseRepository = course;
        }

        public ViewResult DisplayPage()
        {
            ViewBag.Title = "Display Page";
            //return View(Repository.Courses.Where(r => r.CourseName != null));
            return View(courseRepository.Courses.Where(r => r.CourseName != null));
        }

        public ViewResult DataPage(int courseId)
        {
            ViewBag.Title = "Data Page";
            //return View(Repository.Courses.FirstOrDefault(c => c.CourseId == courseId));
            return View(courseRepository.Courses.FirstOrDefault(c => c.CourseId == courseId));
        }

        [HttpGet]
        public ViewResult InsertPage()
        {
            ViewBag.Title = "Insert Page";
            return View();
        }

        [HttpPost]
        public ViewResult InsertPage(Course course)
        {
            if (ModelState.IsValid)
            {
                //int newId = Repository.Courses.Select(c => c).Count(); //Counting how many courses
                //course.CourseId = newId + 1; // and incrementing Id + 1 if I have 7 courses the next course will have Id 8
                //Repository.AddCourse(course);  //Adding course to Repository              
                //return View("DisplayPage", Repository.Courses);

                courseRepository.SaveCourse(course);
                return View("DisplayPage", courseRepository.Courses);
            }
            else
            {
                // there is a validation error
                return View();
            }
        }

        public ViewResult UserPage()
        {
            ViewBag.Title = "User Page";
            return View(courseRepository.Courses.Where(r => r.CourseName != null));
        }
        
        [HttpPost]
        public IActionResult Update(Course course)
        {
            if (ModelState.IsValid)
            {
                courseRepository.SaveCourse(course);
                TempData["message"] = $"{course.CourseName} has been saved";
                return RedirectToAction("DisplayPage");
            }
            else
            {
                // there is something wrong with the data values
                return View(course);
            }
        }

        [HttpPost]
        public IActionResult Delete(int courseId)
        {
            Course deletedCourse = courseRepository.DeleteCourse(courseId);
            if (deletedCourse != null)
            {
                TempData["message"] = $"{deletedCourse.CourseName} was deleted";
            }
            return RedirectToAction("DisplayPage");
        }
    }
}
