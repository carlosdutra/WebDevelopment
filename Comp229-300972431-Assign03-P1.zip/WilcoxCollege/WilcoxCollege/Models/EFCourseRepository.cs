﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace WilcoxCollege.Models
{
    public class EFCourseRepository : ICourseRepository
    {
        private ApplicationDbContext context;

        public EFCourseRepository(ApplicationDbContext ctx)
        {
            context = ctx;
        }

        public IQueryable<Course> Courses => context.Courses;
        //public IQueryable<Course> Courses => context.Courses.Include(c => c.Students);

        public void SaveCourse(Course course)
        {
            if (course.CourseId == 0)
            {
                context.Courses.Add(course);
            }
            else
            {
                Course dbEntry = context.Courses
                    .FirstOrDefault(p => p.CourseName == course.CourseName);
                if (dbEntry != null)
                {
                    dbEntry.CourseName = course.CourseName;
                    dbEntry.CourseCode = course.CourseCode;
                    dbEntry.CourseDescription = course.CourseDescription;
                }
            }
            context.SaveChanges();
        }

        public Course DeleteCourse(int courseId)
        {
            Course dbEntry = context.Courses
                .FirstOrDefault(c => c.CourseId == courseId);
            if (dbEntry != null)
            {
                context.Courses.Remove(dbEntry);
                context.SaveChanges();
            }
            return dbEntry;
        }
    }
}
