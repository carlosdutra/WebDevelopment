﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WilcoxCollege.Models
{
    public class EFStudentRepository : IStudentRepository
    {
        private ApplicationDbContext context;

        public EFStudentRepository(ApplicationDbContext ctx)
        {
            context = ctx;
        }

        public IQueryable<Student> Students => context.Students;

        public void SaveStudent(Student course)
        {
            //if (course.CourseId == 0)
            //{
            //    context.Courses.Add(course);
            //}
            //else
            //{
            //    Course dbEntry = context.Courses
            //        .FirstOrDefault(p => p.CourseName == course.CourseName);
            //    if (dbEntry != null)
            //    {
            //        dbEntry.CourseName = course.CourseName;
            //        dbEntry.CourseCode = course.CourseCode;
            //        dbEntry.CourseDescription = course.CourseDescription;
            //    }
            //}
            //context.SaveChanges();
        }
    }
}
