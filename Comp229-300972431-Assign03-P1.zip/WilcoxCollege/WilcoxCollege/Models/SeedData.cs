﻿using Microsoft.AspNetCore.Builder;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WilcoxCollege.Models
{
    public static class SeedData
    {
        public static void EnsurePopulated(IApplicationBuilder app)
        {
            ApplicationDbContext context = app.ApplicationServices
                .GetRequiredService<ApplicationDbContext>();
            context.Database.Migrate();
            if (!context.Courses.Any())
            {
                context.Courses.AddRange(
                    new Course
                    {
                        CourseName = "Programming I",
                        CourseCode = "PROG01",
                        CourseDescription = "Level I of Programming C#",
                        //CourseId = 0001
                    },
                    new Course
                    {
                        CourseName = "Programming II",
                        CourseCode = "PROG02",
                        CourseDescription = "Level II of Programming C#",
                        //CourseId = 0002
                    },
                    new Course
                    {
                        CourseName = "Advanced Database Concepts",
                        CourseCode = "DATA02",
                        CourseDescription = "Level Advanced of Database",
                        //CourseId = 0010
                    }
                );
                context.SaveChanges();
            }
        }

    }
}
