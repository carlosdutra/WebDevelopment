﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WilcoxCollege.Models
{
    public interface ICourseRepository
    {
        IQueryable<Course> Courses { get; }

        void SaveCourse(Course course);

        Course DeleteCourse(int courseId);
    }
}
