﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CollegeWebsite.Models;
using Microsoft.AspNetCore.Mvc;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace CollegeWebsite.Controllers
{
    public class HomeController : Controller
    {
        // GET: /<controller>/
        public IActionResult Index()
        {
            return View();
        }

        //public ViewResult RegisteredStudents()
        //{
        //    return View();
        //}

        public ViewResult ListStudents()
        {
            return View(StudentRepository.Students.OrderBy(r => r.lastName).ToList());
        }

        [HttpGet]
        public ViewResult InsertStudent()
        {
            return View();
        }

        [HttpPost]
        public ViewResult InsertStudent(Student student)
        {
            if (ModelState.IsValid)
            {
                StudentRepository.AddStudent(student);
                return View("SuccessRegistration", student);
            }
            else
            {
                // there is a validation error
                return View();
            }
        }


        public ViewResult RegisteredStudents()
        {
            return View(StudentRepository.Students.Where(r => r.firstName != null));
        }
    }
}
