﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CollegeWebsite.Models
{
    public class Student
    {
        public int studentNumber { get; set; }
        public string firstName { get; set; }
        public string lastName { get; set; }
        public string email { get; set; }
        public string course { get; set; }
        public string semester { get; set; }

        public DateTime dateRegistered { get; set; }

        public Student()
        {
            dateRegistered = DateTime.Now;
        }
        
    }
}
