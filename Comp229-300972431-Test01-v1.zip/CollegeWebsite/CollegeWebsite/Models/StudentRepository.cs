﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CollegeWebsite.Models
{
    public class StudentRepository
    {
        private static List<Student> listOfStudents = new List<Student>();

        public static IEnumerable<Student> Students
        {
            get
            {
                return listOfStudents;
            }
        }

        public static void AddStudent(Student students)
        {
            listOfStudents.Add(students);
        }
    }
}
