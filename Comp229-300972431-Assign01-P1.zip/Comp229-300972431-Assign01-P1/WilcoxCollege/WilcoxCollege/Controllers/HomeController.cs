﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace WilcoxCollege.Controllers
{
    public class HomeController : Controller
    {
        // GET: /<controller>/
        public ViewResult Index()
        {
            ViewBag.Title = "Wilcox College - Home";
            ViewBag.Message = "Wilcox College";
            return View();
        }

        
        public ViewResult DisplayPage()
        {
            return View();
        }

        public ViewResult DataPage()
        {
            return View();
        }

        public ViewResult InsertPage()
        {
            return View();
        }

        public ViewResult UserPage()
        {
            return View();
        }
    }
}
